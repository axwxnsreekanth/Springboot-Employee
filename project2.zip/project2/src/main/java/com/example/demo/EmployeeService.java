package com.example.demo;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    public Employee createEmployee(String name, int age, char designation) {
        double salary = 0;
        if (designation == 'P') salary = 20000;
        else if (designation == 'M') salary = 25000;
        else if (designation == 'T') salary = 15000;
        else return null; 

        Employee employee = new Employee(name, age, designation, salary);
        return employeeRepository.save(employee);
    }

    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    public Employee raiseSalary(String name, int percent) {
        Employee employee = employeeRepository.findByName(name);
        if (employee != null) {
            double newSalary = employee.getSalary() + (employee.getSalary() * percent / 100);
            employee.setSalary(newSalary);
            return employeeRepository.save(employee);
        }
        return null; // Employee not found
    }
}
