package com.example.demo;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.List;
import java.util.Scanner;

@SpringBootApplication
public class DemoApp implements CommandLineRunner {

    @Autowired
    private EmployeeService employeeService;

    public static void main(String[] args) {
        SpringApplication.run(DemoApp.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\nPlease enter your choice:");
            System.out.println("1. Create Employee");
            System.out.println("2. Display Employees");
            System.out.println("3. Raise Salary");
            System.out.println("4. Exit");

            int choice = sc.nextInt();
            sc.nextLine();  // Consume the newline

            switch (choice) {
                case 1:
                    createEmployee(sc);
                    break;
                case 2:
                    displayEmployees();
                    break;
                case 3:
                    raiseSalary(sc);
                    break;
                case 4:
                    System.out.println("Exiting... Thank you!");
                    return;
                default:
                    System.out.println("Invalid option! Please try again.");
            }
        }
    }

    private void createEmployee(Scanner sc) {
        try {
            System.out.print("Enter name: ");
            String name = sc.nextLine();

            System.out.print("Enter age (20-60): ");
            int age = sc.nextInt();
            sc.nextLine();

            System.out.print("Enter designation (P/M/T): ");
            char designation = Character.toUpperCase(sc.next().charAt(0));
            sc.nextLine();

            Employee employee = employeeService.createEmployee(name, age, designation);
            if (employee != null) {
                System.out.println("Employee added successfully!");
            } else {
                System.out.println("Invalid designation entered!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void displayEmployees() {
        List<Employee> employees = employeeService.getAllEmployees();
        if (employees.isEmpty()) {
            System.out.println("No employees found.");
        } else {
            System.out.println("\n--- Employee Details ---");
            for (Employee employee : employees) {
                System.out.println("Name: " + employee.getName() +
                        ", Age: " + employee.getAge() +
                        ", Designation: " + employee.getDesignation() +
                        ", Salary: " + employee.getSalary());
            }
        }
    }

    private void raiseSalary(Scanner sc) {
        try {
            System.out.print("Enter name of employee to raise salary: ");
            String name = sc.nextLine();

            System.out.print("Enter raise percentage (1-10): ");
            int percent = sc.nextInt();
            sc.nextLine();

            Employee updatedEmployee = employeeService.raiseSalary(name, percent);
            if (updatedEmployee != null) {
                System.out.println("Salary raised successfully! New salary: " + updatedEmployee.getSalary());
            } else {
                System.out.println("Employee not found!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
