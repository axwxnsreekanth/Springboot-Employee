package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    @Autowired
    private EmployeeRepository employeeRepository;

    // Create Employee
    @PostMapping
    public String createEmployee(@RequestBody Employee employee) {
        // Validate Age Range
        if (employee.getAge() < 20 || employee.getAge() > 60) {
            return "Invalid age! Age must be between 20 and 60.";
        }

        // Validate Designation
        if (employee.getDesignation() != 'P' && employee.getDesignation() != 'M' && employee.getDesignation() != 'T') {
            return "Invalid designation! Only 'P', 'M', or 'T' are allowed.";
        }

        // Save the employee to the database
        employeeRepository.save(employee);
        return "Employee added successfully!";
    }

    // Get All Employees
    @GetMapping
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    // Update Salary
    @PutMapping("/{name}/{percentage}")
    public String raiseSalary(@PathVariable String name, @PathVariable int percentage) {
        // Validate Raise Percentage
        if (percentage < 1 || percentage > 10) {
            return "Invalid raise percentage! It should be between 1 and 10.";
        }

        Employee employee = employeeRepository.findByName(name);
        if (employee == null) {
            return "Employee not found!";
        }

        // Calculate and update salary
        double newSalary = employee.getSalary() + (employee.getSalary() * percentage / 100);
        employee.setSalary(newSalary);
        employeeRepository.save(employee);
        return "Salary updated successfully!";
    }
}
