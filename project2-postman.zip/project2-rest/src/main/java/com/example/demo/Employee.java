package com.example.demo;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;

@Entity
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private int age;
    private char designation;
    private double salary;

    // Default constructor
    public Employee() {}

    // Constructor
    public Employee(String name, int age, char designation) {
        this.name = name;
        this.age = age;
        this.designation = designation;
        this.salary = calculateSalary(designation); // Automatically set salary based on designation
    }

    // Method to calculate salary based on designation
    private double calculateSalary(char designation) {
        if (designation == 'P') {
            return 20000;
        } else if (designation == 'M') {
            return 25000;
        } else if (designation == 'T') {
            return 15000;
        }
        return 0; // Default salary if designation is invalid
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public char getDesignation() {
        return designation;
    }

    public void setDesignation(char designation) {
        this.designation = designation;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }
}
