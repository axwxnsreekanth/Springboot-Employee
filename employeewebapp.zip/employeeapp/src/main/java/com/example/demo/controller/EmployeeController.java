package com.example.demo.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Employee;
import com.example.demo.repo.EmployeeRepository;



@Controller
public class EmployeeController {

    @Autowired
    private EmployeeRepository repo;

    // Login page
    @GetMapping("/")
    public String login() {
        return "login";
    }

    @PostMapping("/login")
    public String loginValidation(@RequestParam String username,
                                  @RequestParam String password,
                                  Model model) {

        if (username.equals("user") && password.equals("user123")) {
            return "home";
        } else {
            model.addAttribute("error", "Invalid Username or Password");
            return "login";
        }
    }


    // Create employee page
    @GetMapping("/create")
    public String createEmployeePage() {
        return "createEmployee";
    }

    // Save employee
    @PostMapping("/saveEmployee")
    public String saveEmployee(@RequestParam String name,
                               @RequestParam int age,
                               @RequestParam char designation,
                               Model model) {
    	if(age<20 || age>60) {
            model.addAttribute("error", "Age should be between 20 and 60");
            return "createEmployee";
    	}
        double salary;

        switch (designation) {
            case 'M': salary = 25000; break;
            case 'P': salary = 20000; break;
            case 'T': salary = 15000; break;
            default:
                model.addAttribute("error", "Invalid Designation");
                return "createEmployee";
        }

        Employee emp = new Employee(name, age, designation, salary);
        repo.save(emp);

        return "home";
    }

    // Display employees
    @GetMapping("/display")
    public String displayEmployees(Model model) {
        List<Employee> employees = repo.findAll();
        model.addAttribute("employees", employees);
        return "displayEmployees";
    }

    // Raise salary page
    @GetMapping("/raise")
    public String raiseSalaryPage() {
        return "raiseSalary";
    }

    // Update salary
    @PostMapping("/updateSalary")
    public String updateSalary(@RequestParam String name,
                               @RequestParam int percentage,
                               Model model) {

        if (percentage < 1 || percentage > 10) {
            model.addAttribute("error", "Percentage must be between 1 and 10");
            return "raiseSalary";
        }

        Employee emp = repo.findByName(name);
        if (emp != null) {
            double newSalary = emp.getSalary() +
                    (emp.getSalary() * percentage / 100);
            emp.setSalary(newSalary);
            repo.save(emp);
        }

        return "home";
    }

    // Exit
    @GetMapping("/logout")
    public String logout() {
        return "login";
    }
}
